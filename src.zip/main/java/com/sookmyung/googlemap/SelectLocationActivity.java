package com.sookmyung.googlemap;

import android.app.Activity;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

/**
 * Created by jsm95 on 2017-07-24.
 */

public class SelectLocationActivity extends Activity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectlocations);

        Button button_select =(Button)findViewById(R.id.button_select);
        final TextView tv = (TextView)findViewById(R.id.textView);
        final EditText editText_location = (EditText)findViewById(R.id.editText_location);

        final Geocoder geocoder = new Geocoder(this);

        button_select.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                List<Address> list = null;
                String str_location = editText_location.getText().toString();
                try{
                    list = geocoder.getFromLocationName(str_location, 10);
                } catch (IOException e){
                    e.printStackTrace();

                    Log.e("test", "입출력 오류 - 서버에서 주소변환시 에러 발생");
                }

                if(list != null) {
                    if (list.size() == 0) {
                       Toast.makeText(SelectLocationActivity.this,"해당 주소 없음", Toast.LENGTH_LONG).show();
                    } else {
                        Address addr = list.get(0);
                        double lat = addr.getLatitude();
                        double lon = addr.getLongitude();
                        String str_lat = String.format("%.6f",lat);
                        lat = Double.parseDouble(str_lat);

                        String str_lon = String.format("%.6f",lon);
                        lon = Double.parseDouble(str_lon);

                        tv.setText("시작 위치"+Double.toString(lat) +", " +Double.toString(lon));

                        Intent intent = new Intent(SelectLocationActivity.this, MapsActivity.class);
                        intent.putExtra("lat", lat);
                        intent.putExtra("lon", lon);
                        startActivity(intent);
                    }
                }
            }
        });
    }


}
